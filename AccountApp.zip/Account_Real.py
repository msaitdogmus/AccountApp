import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json
from datetime import datetime
import os


try:
    from tkcalendar import Calendar
except ImportError:
    Calendar = None
    messagebox.showwarning("Uyarı", "tkcalendar modülü yok. Tarih seçimi için takvim şuan kullanılamıyor :/")

product_entries = []
product_id_counter =1

overall_purchase_cost = 0.0
overall_sale_revenue = 0.0

current_day = datetime.now().strftime("%d.%m.%Y")
daily_purchase_cost =0.0
daily_sale_revenue =0.0

customer_debts={}
transaction_logs ={}
notes_log =[]
sales_transactions=[]

Data_file = "data.json"

def save_data():
    data =\
        {
        "product_entries": product_entries,
        "product_id_counter": product_id_counter,
        "overall_purchase_cost": overall_purchase_cost,
        "overall_sale_revenue": overall_sale_revenue,
        "current_day": current_day,
        "daily_purchase_cost": daily_purchase_cost,
        "daily_sale_revenue": daily_sale_revenue,
        "transaction_logs": transaction_logs,
        "notes_log": notes_log,
        "customer_debts": customer_debts,
        "sales_transactions": sales_transactions
    }
    try:
        with open(Data_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii= False, indent= 4)
    except Exception as notveri:
        print("Veriler kayıt değil",notveri)


def load_data():
    global product_entries, product_id_counter, overall_purchase_cost, overall_sale_revenue
    global current_day, daily_purchase_cost, daily_sale_revenue
    global transaction_logs, notes_log, customer_debts, sales_transactions

    if os.path.exists(Data_file):
        try:
            with open(Data_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                product_entries[:] = data.get("product_entries", [])
                product_id_counter = data.get("product_id_counter", 1)
                overall_purchase_cost = data.get("overall_purchase_cost", 0.0)
                overall_sale_revenue = data.get("overall_sale_revenue", 0.0)
                current_day = data.get("current_day", datetime.now().strftime("%d.%m.%Y"))
                daily_purchase_cost = data.get("daily_purchase_cost", 0.0)
                daily_sale_revenue = data.get("daily_sale_revenue", 0.0)
                transaction_logs.clear()
                transaction_logs.update(data.get("transaction_logs", {}))
                notes_log[:] = data.get("notes_log", [])
                customer_debts.clear()
                customer_debts.update(data.get("customer_debts", {}))
                sales_transactions[:] = data.get("sales_transactions", [])
        except Exception as e:
            print("Veriler yüklenirken hata:", e)
    today = datetime.now().strftime("%d.%m.%Y")
    if today not in transaction_logs:
        transaction_logs[today] = []

def append_transaction_log(message):
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_date = datetime.now().strftime("%d.%m.%Y")
    if message.startswith("ALIŞ"):
        tag = "purchase"
    elif message.startswith("SATIŞ"):
        tag = "sale"
    elif message.startswith("ÖDEME"):
        tag = "payment"
    else:
        tag = "default"
    full_message = f"{current_time} - {message}"
    if log_date not in transaction_logs:
        transaction_logs[log_date] = []
    transaction_logs[log_date].append({"time": current_time, "message": message, "type": tag})
    if selected_log_date.get() == log_date:
        transaction_log_text.config(state='normal')
        transaction_log_text.insert(tk.END, full_message + "\n", tag)
        transaction_log_text.see(tk.END)
        transaction_log_text.config(state='disabled')


def update_transaction_log_display():

    transaction_log_text.config(state='normal')
    transaction_log_text.delete("1.0", tk.END)
    log_date = selected_log_date.get()
    if log_date in transaction_logs:
        for entry in transaction_logs[log_date]:
            full_message = f"{entry['time']} - {entry['message']}\n"
            transaction_log_text.insert(tk.END, full_message, entry['type'])
    transaction_log_text.config(state='disabled')

def open_date_picker():
    """Takvim şeklinde tarih seçimi yapar; seçilen tarih log görüntülemede kullanılır.
       Gelecek tarihlerin seçilmesini engellemek için maxdate olarak bugünün tarihi ayarlanır."""
    if Calendar is None:
        messagebox.showerror("Hata", "tkcalendar modülü yüklü değil!")
        return

    def on_date_select():
        sel_date = cal.selection_get()
        formatted = sel_date.strftime("%d.%m.%Y")
        selected_log_date.set(formatted)
        update_transaction_log_display()
        top.destroy()

    top = tk.Toplevel(root)
    top.title("Tarih Seç")
    today = datetime.now().date()
    cal = Calendar(top, date_pattern="dd.mm.yyyy", maxdate=today)
    cal.pack(padx=10, pady=10)
    select_btn = tk.Button(top, text="Tarih Seç", command=on_date_select)
    select_btn.pack(pady=5)

def perform_log_search():
    query = search_entry.get().strip().lower()
    if not query:
        messagebox.showinfo("Bilgi", "Lütfen aranacak kelime girin.")
        return
    search_today = messagebox.askyesno("Arama Seçeneği",
                                       "Aramayı sadece bugün için mi yapmak istiyorsunuz?\n(Evet: Bugün, Hayır: Tüm loglar)")
    transaction_log_text.config(state='normal')
    transaction_log_text.delete("1.0", tk.END)
    if search_today:
        log_date = selected_log_date.get()
        if log_date in transaction_logs:
            for entry in transaction_logs[log_date]:
                if query in entry['message'].lower():
                    full_message = f"{entry['time']} - {entry['message']}\n"
                    transaction_log_text.insert(tk.END, full_message, entry['type'])
        else:
            messagebox.showinfo("Arama", "Bugün için log bulunamadı.")
    else:
        for date, entries in transaction_logs.items():
            for entry in entries:
                if query in entry['message'].lower():
                    full_message = f"{date} {entry['time']} - {entry['message']}\n"
                    transaction_log_text.insert(tk.END, full_message, entry['type'])
    transaction_log_text.config(state='disabled')

def show_product_summary():
    summary_win = tk.Toplevel(root)
    summary_win.title("Ürün Özeti")
    summary_win.geometry("700x400")

    tree = ttk.Treeview(summary_win,
                        columns=("ID", "Ürün Adı", "Alış Fiyatı", "Adet", "Toplam Alış", "Satış Geliri", "Genel Kâr"),
                        show="headings")
    tree.heading("ID", text="ID")
    tree.heading("Ürün Adı", text="Ürün Adı")
    tree.heading("Alış Fiyatı", text="Birim Alış")
    tree.heading("Adet", text="Stok")
    tree.heading("Toplam Alış", text="Toplam Alış")
    tree.heading("Satış Geliri", text="Satış Geliri")
    tree.heading("Genel Kâr", text="Genel Kâr")

    tree.column("ID", width=40)
    tree.column("Ürün Adı", width=120)
    tree.column("Alış Fiyatı", width=80)
    tree.column("Adet", width=60)
    tree.column("Toplam Alış", width=100)
    tree.column("Satış Geliri", width=100)
    tree.column("Genel Kâr", width=100)

    tree.pack(expand=True, fill="both", padx=10, pady=10)

    def populate_tree():
        tree.delete(*tree.get_children())
        for entry in product_entries:
            product_profit = entry["sale_revenue"] - entry["total_purchase_cost"]
            tree.insert("", tk.END, values=(
                entry["id"],
                entry["name"],
                f"{entry['purchase_price']:.2f}",
                entry["quantity"],
                f"{entry['total_purchase_cost']:.2f}",
                f"{entry['sale_revenue']:.2f}",
                f"{product_profit:.2f}"
            ))

    populate_tree()

    def delete_selected():
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Hata", "Lütfen silinecek kaydı seçin.")
            return
        for item in selected:
            values = tree.item(item, "values")
            prod_id = int(values[0])
            for idx, entry in enumerate(product_entries):
                if entry["id"] == prod_id:
                    global overall_purchase_cost, daily_purchase_cost
                    overall_purchase_cost -= entry["total_purchase_cost"]
                    daily_purchase_cost -= entry["total_purchase_cost"]
                    del product_entries[idx]
                    append_transaction_log(f"ÜRÜN SİL: {entry['name']} (ID: {prod_id}) silindi.")
                    break
        populate_tree()
        update_sales_product_options()
        update_product_name_combobox()
        update_total_products_label()
        update_overall_profit()

    del_btn = tk.Button(summary_win, text="Seçili Kaydı Sil", command=delete_selected)
    del_btn.pack(pady=5)

    close_btn = tk.Button(summary_win, text="Kapat", command=summary_win.destroy)
    close_btn.pack(pady=5)

def update_overall_profit():
    global current_day, daily_purchase_cost, daily_sale_revenue
    today_str = datetime.now().strftime("%d.%m.%Y")
    if today_str != current_day:
        current_day = today_str
        daily_purchase_cost = 0.0
        daily_sale_revenue = 0.0
    today_profit = daily_sale_revenue - daily_purchase_cost
    overall_profit_label.config(text=f"Bugünün Net Kâr: {today_profit:.2f} TL")

def update_product_name_combobox():
    names = sorted(list({entry["name"] for entry in product_entries}))
    product_name_combobox['values'] = names


def update_sales_product_options():
    options=[]
    for entry in product_entries:
        options.append(
            f"{entry['id']} - {entry['name']} (Alış: {entry['purchase_price']:.2f} TL, Stok: {entry['quantity']})")
    sale_product_combobox['values'] = options


def update_total_products_label():
    total = sum(entry["total_units_purchased"] for entry in product_entries)
    product_frame.config(text=f"Ürün Ekleme (Toplam Eklenen Ürün: {total})")


def add_product():
    global product_id_counter, overall_purchase_cost, daily_purchase_cost
    name = product_name_combobox.get().strip()
    if name == "":
        messagebox.showerror("Hata", "Lütfen ürün adını girin.")
        return
    try:
        price = float(product_price_entry.get().strip())
    except ValueError:
        messagebox.showerror("Hata", "Lütfen geçerli bir alış fiyatı girin.")
        return
    try:
        quantity = int(product_quantity_entry.get().strip())
    except ValueError:
        messagebox.showerror("Hata", "Lütfen geçerli bir adet girin.")
        return
    purchase_cost = price * quantity
    overall_purchase_cost += purchase_cost
    if datetime.now().strftime("%d.%m.%Y") == current_day:
        daily_purchase_cost += purchase_cost
    else:
        daily_purchase_cost = purchase_cost
    found = False
    for entry in product_entries:
        if entry["name"].lower() == name.lower() and entry["purchase_price"] == price:
            entry["quantity"] += quantity
            entry["total_purchase_cost"] += purchase_cost
            entry["total_units_purchased"] += quantity
            found = True
            msg = (f"ALIŞ: {quantity} adet {name} eklenerek mevcut kayda güncelleme yapıldı. "
                   f"Birim Fiyat: {price} TL, Toplam Maliyet: {purchase_cost:.2f} TL. "
                   f"Yeni stok: {entry['quantity']}.")
            break
    if not found:
        new_entry = {
            "id": product_id_counter,
            "name": name,
            "purchase_price": price,
            "quantity": quantity,
            "total_purchase_cost": purchase_cost,
            "sale_revenue": 0.0,
            "total_units_purchased": quantity,
            "total_units_sold": 0,
            "default_sale_price": price * 1.2
        }
        product_entries.append(new_entry)
        product_id_counter += 1
        msg = (f"ALIŞ: {quantity} adet {name} eklendi. "
               f"Birim Fiyat: {price} TL, Toplam Maliyet: {purchase_cost:.2f} TL. "
               f"Stok: {quantity}.")
    messagebox.showinfo("Bilgi", msg)
    append_transaction_log(msg)
    update_sales_product_options()
    update_product_name_combobox()
    update_total_products_label()
    update_overall_profit()
    product_name_combobox.set("")
    product_price_entry.delete(0, tk.END)
    product_quantity_entry.delete(0, tk.END)

def update_sale_price(*args):
    selection = sale_product_combobox.get().strip()
    if selection == "":
        sale_price_entry.delete(0, tk.END)
        return
    try:
        prod_id = int(selection.split(" - ")[0])
    except (IndexError, ValueError):
        sale_price_entry.delete(0, tk.END)
        return
    for entry in product_entries:
        if entry["id"] == prod_id:
            sale_price_entry.delete(0, tk.END)
            sale_price_entry.insert(0, f"{entry['default_sale_price']:.2f}")
            break


def sale_product():
    global overall_sale_revenue, daily_sale_revenue
    selection = sale_product_combobox.get().strip()
    if selection == "":
        messagebox.showerror("Hata", "Lütfen satış yapılacak ürünü seçin.")
        return
    try:
        prod_id = int(selection.split(" - ")[0])
    except (IndexError, ValueError):
        messagebox.showerror("Hata", "Geçersiz ürün seçimi.")
        return
    try:
        sale_quantity = int(sale_quantity_entry.get().strip())
    except ValueError:
        messagebox.showerror("Hata", "Lütfen geçerli bir satış adedi girin.")
        return
    try:
        sale_price = float(sale_price_entry.get().strip())
    except ValueError:
        messagebox.showerror("Hata", "Lütfen geçerli bir satış fiyatı girin.")
        return
    customer_name = customer_entry.get().strip()
    if customer_name == "":
        messagebox.showerror("Hata", "Lütfen satış yapılan kişinin adını girin.")
        return
    target = None
    for entry in product_entries:
        if entry["id"] == prod_id:
            target = entry
            break
    if target is None:
        messagebox.showerror("Hata", "Seçilen ürün bulunamadı.")
        return
    if sale_quantity > target["quantity"]:
        messagebox.showerror("Hata", "Yeterli stok yok!")
        return
    total_sale = sale_price * sale_quantity
    overall_sale_revenue += total_sale
    if datetime.now().strftime("%d.%m.%Y") == current_day:
        daily_sale_revenue += total_sale
    else:
        daily_sale_revenue = total_sale
    target["quantity"] -= sale_quantity
    target["sale_revenue"] += total_sale
    target["total_units_sold"] += sale_quantity
    if customer_name in customer_debts:
        customer_debts[customer_name] += total_sale
    else:
        customer_debts[customer_name] = total_sale
    sale_record = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "product_id": prod_id,
        "name": target["name"],
        "quantity": sale_quantity,
        "sale_price": sale_price,
        "total_sale": total_sale,
        "purchase_price": target["purchase_price"]
    }
    sales_transactions.append(sale_record)
    msg = (f"SATIŞ: {sale_quantity} adet {target['name']} satıldı. "
           f"Birim Satış Fiyatı: {sale_price:.2f} TL, Toplam Gelir: {total_sale:.2f} TL. "
           f"Kalan stok: {target['quantity']}. "
           f"Satış yapılan kişi: {customer_name}. "
           f"Yeni Borç: {customer_debts[customer_name]:.2f} TL.")
    messagebox.showinfo("Satış Bilgisi", msg)
    append_transaction_log(msg)
    update_overall_profit()
    update_sales_product_options()
    update_total_products_label()
    sale_product_combobox.set("")
    sale_price_entry.delete(0, tk.END)
    sale_quantity_entry.delete(0, tk.END)
    customer_entry.delete(0, tk.END)

def open_customer_debt_window():
    debt_win = tk.Toplevel(root)
    debt_win.title("Müşteri Borçları ve Ödeme")
    debt_win.geometry("400x500")
    tk.Label(debt_win, text="Müşteri Borçları", font=("Arial", 12, "bold")).pack(pady=5)
    debt_listbox = tk.Listbox(debt_win, width=50, height=10)
    debt_listbox.pack(pady=5)

    def update_debt_listbox():
        debt_listbox.delete(0, tk.END)
        for customer, debt in customer_debts.items():
            debt_listbox.insert(tk.END, f"{customer} - {debt:.2f} TL")

    update_debt_listbox()
    selected_customer_label = tk.Label(debt_win, text="Seçilen Müşteri: Yok")
    selected_customer_label.pack(pady=5)
    selected_debt_label = tk.Label(debt_win, text="Mevcut Borç: 0.00 TL")
    selected_debt_label.pack(pady=5)
    payment_frame = tk.Frame(debt_win)
    payment_frame.pack(pady=10)
    tk.Label(payment_frame, text="Ödeme Miktarı (TL):").grid(row=0, column=0, padx=5)
    payment_entry = tk.Entry(payment_frame, width=15)
    payment_entry.grid(row=0, column=1, padx=5)
    add_debt_frame = tk.Frame(debt_win)
    add_debt_frame.pack(pady=10)
    tk.Label(add_debt_frame, text="Ek Borç (TL):").grid(row=0, column=0, padx=5)
    add_debt_entry = tk.Entry(add_debt_frame, width=15)
    add_debt_entry.grid(row=0, column=1, padx=5)

    def on_select(event):
        selection = debt_listbox.curselection()
        if selection:
            index = selection[0]
            item = debt_listbox.get(index)
            customer = item.split(" - ")[0]
            debt = customer_debts.get(customer, 0.0)
            selected_customer_label.config(text=f"Seçilen Müşteri: {customer}")
            selected_debt_label.config(text=f"Mevcut Borç: {debt:.2f} TL")
        else:
            selected_customer_label.config(text="Seçilen Müşteri: Yok")
            selected_debt_label.config(text="Mevcut Borç: 0.00 TL")

    debt_listbox.bind("<<ListboxSelect>>", on_select)

    def make_payment():
        selection = debt_listbox.curselection()
        if not selection:
            messagebox.showerror("Hata", "Lütfen bir müşteri seçin.")
            return
        index = selection[0]
        item = debt_listbox.get(index)
        customer = item.split(" - ")[0]
        try:
            payment = float(payment_entry.get().strip())
        except ValueError:
            messagebox.showerror("Hata", "Lütfen geçerli bir ödeme miktarı girin.")
            return
        current_debt = customer_debts.get(customer, 0.0)
        if payment > current_debt:
            messagebox.showerror("Hata", "Ödeme miktarı mevcut borçtan fazla olamaz.")
            return
        customer_debts[customer] = current_debt - payment
        messagebox.showinfo("Bilgi", f"{customer} adlı müşterinin yeni borcu: {customer_debts[customer]:.2f} TL")
        append_transaction_log(
            f"ÖDEME: {payment:.2f} TL ödendi. {customer} yeni borç: {customer_debts[customer]:.2f} TL")
        update_debt_listbox()
        payment_entry.delete(0, tk.END)
        on_select(None)

    payment_button = tk.Button(debt_win, text="Ödeme Yap", command=make_payment)
    payment_button.pack(pady=5)

    def add_debt():
        selection = debt_listbox.curselection()
        if not selection:
            messagebox.showerror("Hata", "Lütfen bir müşteri seçin.")
            return
        index = selection[0]
        item = debt_listbox.get(index)
        customer = item.split(" - ")[0]
        try:
            extra_debt = float(add_debt_entry.get().strip())
        except ValueError:
            messagebox.showerror("Hata", "Lütfen geçerli bir borç miktarı girin.")
            return
        customer_debts[customer] += extra_debt
        messagebox.showinfo("Bilgi", f"{customer} adlı müşterinin yeni borcu: {customer_debts[customer]:.2f} TL")
        append_transaction_log(
            f"BORÇ EKLE: {extra_debt:.2f} TL eklendi. {customer} yeni borç: {customer_debts[customer]:.2f} TL")
        update_debt_listbox()
        add_debt_entry.delete(0, tk.END)
        on_select(None)

    add_debt_button = tk.Button(debt_win, text="Borç Ekle", command=add_debt)
    add_debt_button.pack(pady=5)

def open_monthly_profit_window():
    mp_win = tk.Toplevel(root)
    mp_win.title("Aylık Kar Tablosu")
    mp_win.geometry("500x400")
    tk.Label(mp_win, text="Tarihi yıl-ay şeklinde girin (örnek: 2025-02):").pack(pady=5)
    month_entry = tk.Entry(mp_win, width=15)
    month_entry.pack(pady=5)
    tree = ttk.Treeview(mp_win, columns=("Ürün Adı", "Toplam Kar (TL)"), show="headings")
    tree.heading("Ürün Adı", text="Ürün Adı")
    tree.heading("Toplam Kar (TL)", text="Toplam Kar (TL)")
    tree.column("Ürün Adı", width=200)
    tree.column("Toplam Kar (TL)", width=150)
    tree.pack(expand=True, fill="both", padx=10, pady=10)

    def calculate_profit():
        month_str = month_entry.get().strip()
        if not month_str:
            messagebox.showerror("Hata", "Lütfen bir ay girin.")
            return
        profit_dict = {}
        for record in sales_transactions:
            if record["date"].startswith(month_str):
                profit = (record["sale_price"] - record["purchase_price"]) * record["quantity"]
                profit_dict[record["name"]] = profit_dict.get(record["name"], 0) + profit
        tree.delete(*tree.get_children())
        if not profit_dict:
            messagebox.showinfo("Bilgi", "Girilen ay için satış bulunamadı.")
            return
        for name, profit in profit_dict.items():
            tree.insert("", tk.END, values=(name, f"{profit:.2f}"))

    calc_btn = tk.Button(mp_win, text="Karı Göster", command=calculate_profit)
    calc_btn.pack(pady=5)
    close_btn = tk.Button(mp_win, text="Kapat", command=mp_win.destroy)
    close_btn.pack(pady=5)

def open_notepad():
    # Not Defteri penceresi
    notepad_win = tk.Toplevel(root)
    notepad_win.title("Not Defteri")
    notepad_win.geometry("600x400")  # Başındaki boşluk kaldırıldı

    # Not girme alanı
    tk.Label(notepad_win, text="Notunuzu girin:").pack(pady=5)
    note_entry = tk.Text(notepad_win, height=4)
    note_entry.pack(fill="x", padx=10, pady=5)  # Yatayda genişlesin

    # Notu kaydetme fonksiyonu
    def save_note():
        content = note_entry.get("1.0", tk.END).strip()
        if content:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            note = f"{current_time} - {content}"
            notes_log.append(note)
            update_notes_listbox()
            note_entry.delete("1.0", tk.END)
        else:
            messagebox.showerror("Hata", "Lütfen not girin.")

    save_button = tk.Button(notepad_win, text="Kaydet", command=save_note)
    save_button.pack(pady=5)

    # Kaydedilen notlar başlığı
    tk.Label(notepad_win, text="Kaydedilen Notlar:").pack(pady=5)

    # Not listesini gösteren Listbox
    notes_listbox = tk.Listbox(notepad_win)
    notes_listbox.pack(fill="both", expand=True, padx=10, pady=5)  # Hem yatay hem dikey genişlesin

    # Listbox'u güncelleyen fonksiyon
    def update_notes_listbox():
        notes_listbox.delete(0, tk.END)
        for note in notes_log:
            notes_listbox.insert(tk.END, note)

    # Seçili notları silme fonksiyonu
    def delete_selected_note():
        selected_indices = notes_listbox.curselection()
        if not selected_indices:
            messagebox.showerror("Hata", "Lütfen silinecek notu seçin!")
            return
        for index in reversed(selected_indices):
            del notes_log[index]
        update_notes_listbox()
        save_data()

    delete_note_button = tk.Button(notepad_win, text="Notu Sil", command=delete_selected_note)
    delete_note_button.pack(pady=5)

    # Pencereyi açılır açılmaz not listesini doldur
    update_notes_listbox()


def on_closing():
    try:
        save_data()
    except Exception as e:
        print("Veriler kaydedilirken hata oluştu:", e)
    root.destroy()

root = tk.Tk()
root.title("Muhasebe Programı")
root.state("zoomed")
load_data()

root.grid_rowconfigure(0, weight=1)
root.grid_rowconfigure(1, weight=2)
root.grid_rowconfigure(2, weight=0)
root.grid_rowconfigure(3, weight=0)
root.grid_columnconfigure(0, weight=1)

top_frame = tk.Frame(root)
top_frame.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
top_frame.grid_columnconfigure(0, weight=1)
top_frame.grid_columnconfigure(1, weight=1)

product_frame = ttk.LabelFrame(top_frame, text="Ürün Ekleme", padding=10)
product_frame.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

tk.Label(product_frame, text="Ürün Adı:").grid(row=0, column=0, sticky="w")
product_name_combobox = ttk.Combobox(product_frame, width=30)
product_name_combobox.grid(row=0, column=1, pady=2)

tk.Label(product_frame, text="Alış Fiyatı (TL):").grid(row=1, column=0, sticky="w")
product_price_entry = tk.Entry(product_frame, width=30)
product_price_entry.grid(row=1, column=1, pady=2)

tk.Label(product_frame, text="Adet:").grid(row=2, column=0, sticky="w")
product_quantity_entry = tk.Entry(product_frame, width=30)
product_quantity_entry.grid(row=2, column=1, pady=2)

add_product_button = tk.Button(product_frame, text="Ürün Ekle", command=add_product)
add_product_button.grid(row=3, column=0, columnspan=2, pady=5)

search_label = tk.Label(product_frame, text="Kelime Arama:")
search_label.grid(row=4, column=0, sticky="w", pady=(10, 2))
search_entry = tk.Entry(product_frame, width=30)
search_entry.grid(row=4, column=1, pady=(10, 2))
search_button = tk.Button(product_frame, text="Ara", command=perform_log_search)
search_button.grid(row=5, column=0, pady=5)
reset_search_button = tk.Button(product_frame, text="Aramayı Sıfırla", command=update_transaction_log_display)
reset_search_button.grid(row=5, column=1, pady=5)

sale_frame = ttk.LabelFrame(top_frame, text="Satış Yap", padding=10)
sale_frame.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

tk.Label(sale_frame, text="Ürün Seçin:").grid(row=0, column=0, sticky="w")
sale_product_combobox = ttk.Combobox(sale_frame, width=40)
sale_product_combobox.grid(row=0, column=1, pady=2)
sale_product_combobox.bind("<<ComboboxSelected>>", update_sale_price)

tk.Label(sale_frame, text="Satış Fiyatı (TL):").grid(row=1, column=0, sticky="w")
sale_price_entry = tk.Entry(sale_frame, width=30)
sale_price_entry.grid(row=1, column=1, pady=2)

tk.Label(sale_frame, text="Satış Adedi:").grid(row=2, column=0, sticky="w")
sale_quantity_entry = tk.Entry(sale_frame, width=30)
sale_quantity_entry.grid(row=2, column=1, pady=2)

tk.Label(sale_frame, text="Müşteri Adı:").grid(row=3, column=0, sticky="w")
customer_entry = tk.Entry(sale_frame, width=30)
customer_entry.grid(row=3, column=1, pady=2)

sale_button = tk.Button(sale_frame, text="Satış Yap", command=sale_product)
sale_button.grid(row=4, column=0, columnspan=2, pady=5)

summary_frame = tk.Frame(root)
summary_frame.grid(row=1, column=0, sticky="nsew", padx=10, pady=10)
summary_frame.grid_rowconfigure(0, weight=1)
summary_frame.grid_columnconfigure(0, weight=1)
transaction_log_text = tk.Text(summary_frame, state='disabled')
transaction_log_text.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
transaction_log_text.tag_config("purchase", foreground="red")
transaction_log_text.tag_config("sale", foreground="green")
transaction_log_text.tag_config("payment", foreground="blue")
transaction_log_text.tag_config("default", foreground="black")

control_frame = tk.Frame(root)
control_frame.grid(row=2, column=0, sticky="ew", padx=10, pady=10)
tk.Label(control_frame, text="Tarih:").grid(row=0, column=0, padx=5, sticky="e")
selected_log_date = tk.StringVar()
selected_log_date.set(datetime.now().strftime("%d.%m.%Y"))
date_button = tk.Button(control_frame, text="Tarih Seç", command=open_date_picker)
date_button.grid(row=0, column=1, padx=5, sticky="w")
selected_date_label = tk.Label(control_frame, textvariable=selected_log_date)
selected_date_label.grid(row=0, column=2, padx=5)
product_summary_button = tk.Button(control_frame, text="Ürün Özeti Görüntüle", command=show_product_summary)
product_summary_button.grid(row=0, column=3, padx=5)
customer_debt_button_control = tk.Button(control_frame, text="Müşteri Borçları", command=open_customer_debt_window)
customer_debt_button_control.grid(row=0, column=4, padx=5)
monthly_profit_button = tk.Button(control_frame, text="Aylık Kar Tablosu", command=open_monthly_profit_window)
monthly_profit_button.grid(row=0, column=5, padx=5)

bottom_frame = tk.Frame(root)
bottom_frame.grid(row=3, column=0, sticky="ew", padx=10, pady=10)
overall_profit_label = tk.Label(bottom_frame, text="Bugünün Net Kâr: 0.00 TL", font=("Arial", 12, "bold"))
overall_profit_label.pack(side="left", padx=10)
notepad_button = tk.Button(bottom_frame, text="Not Defteri", command=open_notepad)
notepad_button.pack(side="right", padx=10)

update_sales_product_options()
update_product_name_combobox()
update_total_products_label()
update_overall_profit()
update_transaction_log_display()

root.protocol("WM_DELETE_WINDOW", on_closing)
root.mainloop()
